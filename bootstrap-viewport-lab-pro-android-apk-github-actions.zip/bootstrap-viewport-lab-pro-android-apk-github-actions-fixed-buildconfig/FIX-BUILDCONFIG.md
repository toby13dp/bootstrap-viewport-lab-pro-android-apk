# BuildConfig fix

De GitHub Actions build faalde omdat `BuildConfig` niet gevonden werd in:

```txt
app/src/main/java/be/creatieplezier/viewportlab/ViewportLabApplication.java
```

Fix in `app/build.gradle`:

```gradle
android {
    namespace "be.creatieplezier.viewportlab"
    compileSdk 35

    buildFeatures {
        buildConfig true
    }

    defaultConfig {
        applicationId "be.creatieplezier.viewportlab"
        minSdk 23
        targetSdk 35
        versionCode 1
        versionName "1.0.0"
    }
}
```
